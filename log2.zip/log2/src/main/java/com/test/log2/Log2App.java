package com.test.log2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Log2App {

	public static void main(String[] args) {
		SpringApplication.run(Log2App.class, args);
	}

}
