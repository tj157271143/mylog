package com.test.log1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Log1App {

	public static void main(String[] args) {
		SpringApplication.run(Log1App.class, args);
	}
}
