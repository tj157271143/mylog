package com.test.log1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Log1Controller {
	
	protected final Logger  log = LoggerFactory.getLogger(this.getClass());  
	
	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@GetMapping("/trace1RestTemplate")
	public String callRestTemplate() {
		log.info("Trace1-----RestTemplate");
		return restTemplate().getForEntity("http://localhost:8081/trace2span?name=RestTemplate", String.class)
				.getBody();
	}

	@GetMapping("/trace1HttpClient")
	public String callHttpClient() {
		log.info("Trace1-----HttpClient");
		String result = HttpClientUtil.doGet("http://localhost:8081/trace2span?name=HttpClient");
		return result;
	}

	@GetMapping("/trace1Nothing")
	public String callHome2() {
		log.info("Trace1-----Nothing");
		test1();
		test2();
		return "hello";
	}

	public void test1() {
		log.info("Trace1-----test1");
	}

	public void test2() {
		log.info("Trace1-----test2");
		test3();
	}

	public void test3() {
		log.info("Trace1-----test3");
	}
}
