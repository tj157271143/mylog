package com.test.log1;

import java.util.UUID;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class LoggerMDCTest {

	private static final Logger logger = LoggerFactory.getLogger(LoggerMDCTest.class);
    @Test
    public void testMDC() throws InterruptedException{
        for (int i=0 ; i<10 ; i++) {
        	logger.info("jhgfjkh");
            new Thread(this::fun).start();
            fun();
        }
        //Thread.sleep(1);
    }
    private void fun(){
        String key = "METHOD-INVOKE-KEY";
        //方法拦截器入口处设置，logback日志配置需要设置 %X{threadUUID}
        MDC.put(key , UUID.randomUUID().toString().replaceAll("-",""));
            //使用的时候，所有调用链上的打印都会加上threadUUID
            fun1();
            //子线程不会被追踪
            new Thread(()->logger.error("ccccccccccccccccc")).start();
        //拦截器finally中需要清除
        MDC.remove(key);
        //MDC.clear();
    }
 
    private void fun1() {
        logger.info("fun1");
        fun2();
    }
 
    private void fun2() {
        logger.info("fun2");
        fun3();
    }
 
    private void fun3() {
        logger.error("fun3");
    }
}
